function ok()
{
    alert("ok")
}